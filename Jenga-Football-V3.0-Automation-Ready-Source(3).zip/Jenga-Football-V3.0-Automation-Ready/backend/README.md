# Jenga Football V3.0 backend — corrected starter

This is the backend only. It is designed to serve the existing client endpoints:

- `GET /health`
- `GET /api/status`
- `POST /api/test-connections`
- `GET /api/football/leagues?season=2026`
- `GET /api/football/fixtures?from=YYYY-MM-DD&to=YYYY-MM-DD&season=YYYY&leagueIds=39,140`
- `POST /api/analyze` with `{"fixture":{"id":123,"home":"Home","away":"Away",...},"season":2026}`
- `GET /api/analyze/:jobId`

## What's corrected

1. Correct 1/X/2 probability validation (three outcomes are summed together); O/U 2.5 and BTTS remain two-outcome checks.
2. A fixture is not labelled provider-verified merely because the client supplied an ID. The official provider must return it.
3. Gemini 2.5 uses `thinkingBudget` rather than the newer `thinkingLevel` field; reasoning options are requested, not guaranteed by a provider.
4. Four valid AI forecasts are required for Round 2; four valid debate replies for Round 3; no final AI consensus is exposed if any required AI/round fails.
5. Missing xG/npxG, opponent-adjusted form, verified lineup/player availability, GK/CB checks, player ratings/depth, motivation evidence, and dated sources are explicitly retained as unmet gates. No fixture is qualified just because the AIs returned confident text.
6. The Poisson output is labelled as an uncalibrated benchmark, not as evidence of a match-specific forecast.

## Setup (Node.js 20+)

1. Set environment variables in your hosting provider's private secret settings, using `.env.example` as a guide.
2. Never expose real API keys in GitHub, the Android app, or this README.
3. Set a unique, long `JENGA_ACCESS_TOKEN` in your host secret settings. Production mode intentionally refuses functional API requests until this token is configured. The Auto AI tab sends it in the `x-jenga-access-token` header.
4. Start with `npm start`. Use `npm run check` to run the syntax check.
5. Open `/health` to check server availability; the health probe is public. In the app, enter the HTTPS service URL and the same access token, save the connection, then run the connection test. A successful health response alone does not verify AI/data providers.

## Important limitations

- This package has not been deployed, connected to your provider keys, or tested against live paid APIs.
- Search results are discovery leads; they are not independent confirmation of injury status, probable XI or press-conference quotes.
- The backend still does not implement a calibrated/opponent-adjusted performance model, validated xG/npxG ingestion, reliable player-rating coverage, a historical backtest, or market-odds value analysis. Therefore the current strict evidence gates are designed to keep match status `NOT QUALIFIED` until those evidence requirements can actually be satisfied.
- In-memory analysis jobs disappear if the server restarts.
- Four providers × three rounds can be slow and can generate API costs. Test with one fixture before running a whole slate.
- API model names and provider effort settings must be confirmed against the access available to your API account.

This software provides estimates for research and entertainment. It cannot guarantee match outcomes or profits.
