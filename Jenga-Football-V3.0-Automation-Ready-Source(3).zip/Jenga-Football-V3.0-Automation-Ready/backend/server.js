import http from 'node:http';
import crypto from 'node:crypto';

const PORT = Number(process.env.PORT || 3000);
const jobs = new Map();
const startedAt = new Date().toISOString();
const env = process.env;
const AI_CONFIG = {
  openai: { key: env.OPENAI_API_KEY, model: env.OPENAI_MODEL || 'gpt-5.6-sol', effort: env.OPENAI_REASONING_EFFORT || 'max', mode: env.OPENAI_REASONING_MODE || 'pro' },
  gemini: { key: env.GEMINI_API_KEY, model: env.GEMINI_MODEL || 'gemini-3.1-pro-preview', effort: (env.GEMINI_THINKING_LEVEL || 'high').toLowerCase() },
  anthropic: { key: env.ANTHROPIC_API_KEY, model: env.ANTHROPIC_MODEL || 'claude-fable-5-1', effort: env.ANTHROPIC_EFFORT || 'max' },
  deepseek: { key: env.DEEPSEEK_API_KEY, model: env.DEEPSEEK_MODEL || 'deepseek-v4-pro', effort: env.DEEPSEEK_REASONING_EFFORT || 'max' }
};
const providerNames = ['openai', 'gemini', 'anthropic', 'deepseek', 'football', 'research'];
const state = Object.fromEntries(providerNames.map(k => [k, {
  status: 'not_tested', lastTest: 'not_tested', configured: false, message: 'Not tested'
}]));
const token = env.JENGA_ACCESS_TOKEN || '';

function json(res, status, body) {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'access-control-allow-origin': '*',
    'access-control-allow-headers': 'content-type,x-jenga-access-token',
    'access-control-allow-methods': 'GET,POST,OPTIONS',
    'cache-control': 'no-store'
  });
  res.end(JSON.stringify(body));
}
async function bodyOf(req) {
  let s = '';
  for await (const c of req) {
    s += c;
    if (s.length > 2_000_000) throw new Error('Request too large (2 MB maximum)');
  }
  if (!s) return {};
  try { return JSON.parse(s); }
  catch { throw new Error('Request body must be valid JSON'); }
}
function auth(req) { if (!token) return env.NODE_ENV !== 'production'; return req.headers['x-jenga-access-token'] === token; }
async function request(url, opts = {}, timeout = 25000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const r = await fetch(url, { ...opts, signal: controller.signal });
    const t = await r.text();
    let j;
    try { j = JSON.parse(t); } catch { j = { raw: t.slice(0, 1200) }; }
    if (!r.ok) {
      const detail = j?.error?.message || j?.message || j?.errors?.join?.(', ') || t.slice(0, 250);
      throw new Error(`HTTP ${r.status}: ${detail || 'Upstream request failed'}`);
    }
    return j;
  } catch (e) {
    if (e?.name === 'AbortError') throw new Error(`Request timed out after ${timeout} ms`);
    throw e;
  } finally { clearTimeout(timer); }
}
function apiSportsHeaders() { return { 'x-apisports-key': env.APISPORTS_KEY || '' }; }
async function football(path) {
  if (!env.APISPORTS_KEY) throw new Error('APISPORTS_KEY is missing');
  return request('https://v3.football.api-sports.io' + path, { headers: apiSportsHeaders() });
}
async function tavily(query) {
  if (!env.TAVILY_API_KEY) throw new Error('TAVILY_API_KEY is missing');
  const r = await request('https://api.tavily.com/search', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ api_key: env.TAVILY_API_KEY, query, search_depth: 'advanced', max_results: 6, include_answer: false, include_raw_content: false })
  });
  return (r.results || []).map(x => ({ title: x.title || '', url: x.url || '', content: x.content || '', publishedDate: x.published_date || '', score: x.score ?? null }));
}

async function aiCall(key, prompt, timeout = 120000) {
  const c = AI_CONFIG[key];
  if (!c?.key) throw new Error(`${key} API key missing`);
  let out = '';
  if (key === 'openai') {
    const j = await request('https://api.openai.com/v1/responses', {
      method: 'POST', headers: { authorization: `Bearer ${c.key}`, 'content-type': 'application/json' },
      body: JSON.stringify({ model: c.model, reasoning: { effort: c.effort, mode: c.mode }, max_output_tokens: 16000, input: prompt })
    }, timeout);
    out = (j.output || []).flatMap(x => x.content || []).filter(x => x.type === 'output_text').map(x => x.text).join('\n');
  } else if (key === 'gemini') {
    const thinkingConfig = c.model.startsWith('gemini-2.5')
      ? { thinkingBudget: c.effort === 'high' || c.effort === 'max' ? 32768 : c.effort === 'medium' ? 8192 : 2048 }
      : { thinkingLevel: ['low', 'medium', 'high'].includes(c.effort) ? c.effort : 'high' };
    const j = await request(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(c.model)}:generateContent?key=${encodeURIComponent(c.key)}`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { thinkingConfig, maxOutputTokens: 16000, responseMimeType: 'application/json' } })
    }, timeout);
    out = (j.candidates?.[0]?.content?.parts || []).map(x => x.text || '').join('\n');
  } else if (key === 'anthropic') {
    const j = await request('https://api.anthropic.com/v1/messages', {
      method: 'POST', headers: { 'x-api-key': c.key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({ model: c.model, max_tokens: 16000, output_config: { effort: c.effort }, messages: [{ role: 'user', content: prompt }] })
    }, timeout);
    out = (j.content || []).filter(x => x.type === 'text').map(x => x.text).join('\n');
  } else {
    const j = await request('https://api.deepseek.com/chat/completions', {
      method: 'POST', headers: { authorization: `Bearer ${c.key}`, 'content-type': 'application/json' },
      body: JSON.stringify({ model: c.model, reasoning_effort: c.effort, max_tokens: 16000, messages: [{ role: 'user', content: prompt }], response_format: { type: 'json_object' } })
    }, timeout);
    out = j.choices?.[0]?.message?.content || '';
  }
  if (!out.trim()) throw new Error('Provider returned an empty response');
  return out;
}
function parseJson(s) {
  const t = String(s).trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  const a = t.indexOf('{'), b = t.lastIndexOf('}');
  if (a < 0 || b < a) throw new Error('AI response did not contain a JSON object');
  try { return JSON.parse(t.slice(a, b + 1)); }
  catch { throw new Error('AI response contained malformed JSON'); }
}
function probability(p, key) {
  const n = Number(p?.probabilities?.[key]);
  if (!Number.isFinite(n) || n < 0 || n > 1) throw new Error(`Invalid/missing probability ${key}`);
  return n;
}
function validatePair(p, a, b) {
  const sum = probability(p, a) + probability(p, b);
  if (Math.abs(sum - 1) > 0.035) throw new Error(`Probability group ${a}/${b} sums to ${(sum * 100).toFixed(1)}%, not 100%`);
}
function normalize(p) {
  for (const k of ['home', 'draw', 'away', 'over25', 'under25', 'bttsYes', 'bttsNo']) probability(p, k);
  // FIX: 1/X/2 is a three-outcome group, not a pair.
  const tri = probability(p, 'home') + probability(p, 'draw') + probability(p, 'away');
  if (Math.abs(tri - 1) > 0.035) throw new Error(`1/X/2 probabilities sum to ${(tri * 100).toFixed(1)}%, not 100%`);
  validatePair(p, 'over25', 'under25');
  validatePair(p, 'bttsYes', 'bttsNo');
  if (!Number.isFinite(Number(p.lambdaHome)) || Number(p.lambdaHome) < 0 || !Number.isFinite(Number(p.lambdaAway)) || Number(p.lambdaAway) < 0) throw new Error('Expected goals (lambdaHome/lambdaAway) are missing or invalid');
  if (!Array.isArray(p.topScores) || p.topScores.length < 1 || !p.topScores.every(s => typeof s.score === 'string' && Number.isFinite(Number(s.probability)) && Number(s.probability) >= 0 && Number(s.probability) <= 1)) throw new Error('At least one valid exact-score forecast is required');
  return p;
}
function validateDebate(p) {
  if (typeof p.challenge !== 'string' || !Array.isArray(p.issues) || !Array.isArray(p.dataGaps)) throw new Error('Debate reply is missing challenge/issues/dataGaps');
  const rp = { probabilities: p.revisedProbabilities };
  for (const k of ['home', 'draw', 'away', 'over25', 'under25', 'bttsYes', 'bttsNo']) {
    const n = Number(rp.probabilities?.[k]);
    if (!Number.isFinite(n) || n < 0 || n > 1) throw new Error(`Debate revisedProbabilities missing/invalid ${k}`);
  }
  const tri = Number(rp.probabilities.home) + Number(rp.probabilities.draw) + Number(rp.probabilities.away);
  if (Math.abs(tri - 1) > 0.035) throw new Error('Debate 1/X/2 probabilities do not sum to 100%');
  validatePair(rp, 'over25', 'under25');
  validatePair(rp, 'bttsYes', 'bttsNo');
  return p;
}
function poissonBaseline(lambdaHome = 1.35, lambdaAway = 1.10) {
  const fact = [1, 1, 2, 6, 24, 120, 720, 5040, 40320];
  const pois = (k, l) => Math.exp(-l) * Math.pow(l, k) / fact[k];
  let home = 0, draw = 0, away = 0, over = 0, btts = 0;
  const scores = [];
  for (let i = 0; i <= 8; i++) for (let j = 0; j <= 8; j++) {
    const pr = pois(i, lambdaHome) * pois(j, lambdaAway);
    if (i > j) home += pr; else if (i === j) draw += pr; else away += pr;
    if (i + j >= 3) over += pr;
    if (i > 0 && j > 0) btts += pr;
    scores.push({ score: `${i}-${j}`, probability: pr });
  }
  const total = home + draw + away;
  scores.sort((a, b) => b.probability - a.probability);
  return {
    lambdaHome, lambdaAway, calibrated: false,
    probabilities: { home: home / total, draw: draw / total, away: away / total, over25: over, under25: 1 - over, bttsYes: btts, bttsNo: 1 - btts },
    topScores: scores.slice(0, 3),
    note: 'Provisional benchmark only. Fixed starting lambdas are not trained on this fixture and cannot qualify a match.'
  };
}
function promptFor(f, ctx, stage, others = [], ownForecast = null) {
  const schema = 'Return ONLY JSON: {"lambdaHome":number,"lambdaAway":number,"probabilities":{"home":0-1,"draw":0-1,"away":0-1,"over25":0-1,"under25":0-1,"bttsYes":0-1,"bttsNo":0-1},"topScores":[{"score":"1-0","probability":0-1},{"score":"1-1","probability":0-1},{"score":"0-1","probability":0-1}],"drawAssessment":"...","risks":["..."],"dataGaps":["..."],"teamNews":"...","gkCb":"...","tactics":"...","motivationSchedule":"...","managerChange":"...","uncertainty":"...","reasoning":"..."}. Probability values are decimals 0-1; home+draw+away, over25+under25, and bttsYes+bttsNo must each sum to 1.';
  const base = `You are an independent football forecasting analyst following Jenga Daily Super-Model V3.0. Fixture: ${f.home} vs ${f.away}; competition ${f.league || 'unknown'}; kickoff ${f.date || ''} ${f.time || ''}; provider status ${f.status || 'unknown'}.\nEvidence packet (unknown fields must remain unknown; never invent): ${JSON.stringify(ctx)}\n${schema}\nExplicitly cover opponent-adjusted recent form only where opponent evidence exists; xG/xGA/npxG if supplied; injuries/suspensions, goalkeeper and two centre-backs, player ratings/bench, tactics, motivation, rest/travel/rotation, manager changes and dated sources. H2H has low weight. Never claim a fact was verified unless the evidence supports it. Distinguish source leads from confirmed facts. A favourite is not a certainty. This is not betting advice.`;
  if (stage === 1) return base + '\nRound 1: sealed independent forecast. Do not assume other analysts agree.';
  if (stage === 2) return `Round 2 adversarial review. Fixture ${f.home} vs ${f.away}. Evidence: ${JSON.stringify(ctx)}. Other independent forecasts (anonymized): ${JSON.stringify(others)}. Challenge contradictions, draw risks, probabilities, missing evidence, scoreline assumptions, and unsupported claims. Return ONLY JSON: {"challenge":"...","issues":["..."],"revisedProbabilities":{"home":0-1,"draw":0-1,"away":0-1,"over25":0-1,"under25":0-1,"bttsYes":0-1,"bttsNo":0-1},"dataGaps":["..."]}. All probability groups must sum to 1. Do not claim missing data was verified.`;
  return base + `\nRound 3: produce your post-debate revised forecast, or explicitly defend your original one. Your sealed Round 1 forecast: ${JSON.stringify(ownForecast)}. Independent debate responses: ${JSON.stringify(others)}. Explain what evidence changed your forecast and what remains uncertain.`;
}

async function getContext(f, season) {
  // FIX: a supplied ID is not proof that the fixture exists. Start false and set true only after provider lookup succeeds.
  const ctx = { fixtureVerifiedByProvider: false, fixture: f, season, asOf: new Date().toISOString(), standings: {}, recentMatches: {}, teamStatistics: {}, injuries: null, sources: [], dataGaps: [] };
  let official = null;
  try {
    if (!f.id) throw new Error('Official fixture provider ID is missing');
    const fx = await football(`/fixtures?id=${encodeURIComponent(f.id)}`);
    official = fx.response?.[0] || null;
    if (!official) throw new Error('Fixture ID not found in provider response');
    ctx.fixtureVerifiedByProvider = true;
    ctx.fixture = { ...f, officialFixture: official };
    const leagueId = official.league?.id || f.leagueId;
    const homeId = official.teams?.home?.id || f.homeId;
    const awayId = official.teams?.away?.id || f.awayId;
    if (leagueId) {
      try {
        const st = await football(`/standings?league=${encodeURIComponent(leagueId)}&season=${encodeURIComponent(season)}`);
        ctx.standings = st.response || {};
      } catch (e) { ctx.dataGaps.push('Standings unavailable: ' + e.message); }
    }
    for (const [name, id] of [['home', homeId], ['away', awayId]]) {
      if (!id) { ctx.dataGaps.push(`${name} team ID missing`); continue; }
      try {
        const recent = await football(`/fixtures?team=${encodeURIComponent(id)}&last=5&season=${encodeURIComponent(season)}`);
        ctx.recentMatches[name] = (recent.response || []).map(x => ({
          id: x.fixture?.id, date: x.fixture?.date, leagueId: x.league?.id, league: x.league?.name,
          homeId: x.teams?.home?.id, awayId: x.teams?.away?.id,
          home: x.teams?.home?.name, away: x.teams?.away?.name, goals: x.goals,
          status: x.fixture?.status?.short
        }));
        if (!ctx.recentMatches[name].length) ctx.dataGaps.push(`${name} recent matches returned empty`);
      } catch (e) { ctx.dataGaps.push(`${name} last-five unavailable: ${e.message}`); }
      try {
        if (!leagueId) throw new Error('League ID missing');
        const st = await football(`/teams/statistics?league=${encodeURIComponent(leagueId)}&season=${encodeURIComponent(season)}&team=${encodeURIComponent(id)}`);
        ctx.teamStatistics[name] = st.response || null;
      } catch (e) { ctx.dataGaps.push(`${name} team statistics unavailable: ${e.message}`); }
    }
    try {
      ctx.injuries = (await football(`/injuries?fixture=${encodeURIComponent(f.id)}`)).response || [];
      if (!ctx.injuries.length) ctx.dataGaps.push('Injury endpoint returned no records; this does not prove there are no injuries.');
    } catch (e) { ctx.dataGaps.push('Fixture injury lookup unavailable: ' + e.message); }
  } catch (e) {
    ctx.fixtureVerifiedByProvider = false;
    ctx.dataGaps.push('Official fixture/context lookup failed: ' + e.message);
  }
  try {
    const q = await tavily(`${f.home} vs ${f.away} team news injuries suspensions likely lineup manager press conference ${f.date || ''}`);
    ctx.sources = q;
    if (!q.length) ctx.dataGaps.push('Current-source research returned no results');
  } catch (e) { ctx.dataGaps.push('Current-source research failed: ' + e.message); }
  if (!ctx.recentMatches.home || !ctx.recentMatches.away || ctx.recentMatches.home.length < 5 || ctx.recentMatches.away.length < 5) ctx.dataGaps.push('Opponent-adjusted last-five form is incomplete; raw results alone are not an opponent adjustment.');
  ctx.dataGaps.push('xG/xGA/npxG need dedicated verified values; team totals or search snippets are not a substitute.');
  ctx.dataGaps.push('Player ratings and confirmed goalkeeper/two-centre-back availability need source-level verification. Search results are leads, not confirmation.');
  return ctx;
}

function makeChecklist(ctx, rounds, valid) {
  const names = ['openai', 'gemini', 'anthropic', 'deepseek'];
  const allR1 = names.every(k => rounds.r1[k]?.ok);
  const allR2 = names.every(k => rounds.r2[k]?.ok);
  const allR3 = names.every(k => rounds.r3[k]?.ok);
  const freshSources = (ctx.sources || []).some(s => s.publishedDate && !Number.isNaN(Date.parse(s.publishedDate)));
  const items = [
    { label: 'Official fixture identity', ok: ctx.fixtureVerifiedByProvider, detail: 'Verified only when the official provider returned the fixture ID.' },
    { label: 'Current table', ok: Object.keys(ctx.standings || {}).length > 0, detail: 'Provider standings response received.' },
    { label: 'Opponent-adjusted last five', ok: false, detail: 'Raw last-five matches may be available; a defensible opponent-strength adjustment is not yet implemented.' },
    { label: 'xG/xGA/npxG', ok: false, detail: 'Dedicated verified metrics are not yet present in the configured feed.' },
    { label: 'Team news', ok: false, detail: 'Web results are leads, not verified team news.' },
    { label: 'GK + centre-backs', ok: false, detail: 'No confirmed goalkeeper and two-centre-back availability audit.' },
    { label: 'Player ratings + depth', ok: false, detail: 'No structured verified ratings / replacement-quality data.' },
    { label: 'Tactics', ok: valid, detail: 'AI assessment exists only after all rounds pass; evidence can still be incomplete.' },
    { label: 'Motivation', ok: false, detail: 'Requires fixture-specific evidence and must not be inferred from league position alone.' },
    { label: 'Schedule / rest', ok: !!ctx.recentMatches.home?.length && !!ctx.recentMatches.away?.length, detail: 'Recent fixtures can help; travel/rest analysis remains incomplete.' },
    { label: 'Pass A baseline', ok: true, detail: 'A provisional Poisson benchmark exists; fixed lambdas are not calibrated.' },
    { label: 'AI Round 1', ok: allR1, detail: `${names.filter(k => rounds.r1[k]?.ok).length}/4 valid forecasts; all four required.` },
    { label: 'AI Round 2 debate', ok: allR2, detail: `${names.filter(k => rounds.r2[k]?.ok).length}/4 valid debates; all four required.` },
    { label: 'AI Round 3 revision', ok: allR3, detail: `${names.filter(k => rounds.r3[k]?.ok).length}/4 valid revisions; all four required.` },
    { label: 'Probability audits', ok: valid, detail: 'Probability totals validated for each successful forecast and debate.' },
    { label: 'Exact-score predictions', ok: valid, detail: 'Each final AI forecast includes valid scoreline probability records.' },
    { label: 'Uncertainty and gaps', ok: valid, detail: 'AI output is retained alongside explicit known data gaps.' },
    { label: 'Dated source freshness', ok: freshSources, detail: 'At least one research result has a parseable publication date.' }
  ];
  const coverage = Math.round(items.filter(x => x.ok).length / items.length * 100);
  return { coverage, passed: items.filter(x => x.ok).length, total: items.length, items };
}
async function analyze(jobId, input) {
  const job = jobs.get(jobId); if (!job) return;
  job.status = 'running';
  try {
    const f = input.fixture || {};
    if (!f.id) throw new Error('Fixture with official provider ID is required');
    const season = Number(input.season || f.providerFixture?.league?.season || f.officialFixture?.league?.season) || new Date().getFullYear();
    const ctx = await getContext(f, season);
    const passA = poissonBaseline();
    const rounds = { r1: {}, r2: {}, r3: {} };
    const statuses = Object.fromEntries(['openai', 'gemini', 'anthropic', 'deepseek'].map(k => [k, { r1: 'pending', r2: 'pending', r3: 'pending', configured: Boolean(AI_CONFIG[k].key) }]));
    const names = ['openai', 'gemini', 'anthropic', 'deepseek'];
    // Pass B: sealed independent estimates. No debate starts unless all four valid forecasts exist.
    for (const k of names) {
      try { const p = normalize(parseJson(await aiCall(k, promptFor(f, ctx, 1)))); rounds.r1[k] = { ok: true, parsed: p }; statuses[k].r1 = 'ok'; }
      catch (e) { rounds.r1[k] = { ok: false, error: e.message }; statuses[k].r1 = 'failed'; statuses[k].r1Error = e.message; }
    }
    // Pass C1: adversarial critique. Each AI sees the other three sealed forecasts, not its peers' labels as truth.
    for (const k of names) {
      try {
        if (!names.every(n => rounds.r1[n]?.ok)) throw new Error('Blocked because all 4 independent Round 1 forecasts are required.');
        const others = names.filter(n => n !== k).map(n => ({ anonymousForecast: rounds.r1[n].parsed }));
        const p = validateDebate(parseJson(await aiCall(k, promptFor(f, ctx, 2, others))));
        rounds.r2[k] = { ok: true, parsed: p }; statuses[k].r2 = 'ok';
      } catch (e) { rounds.r2[k] = { ok: false, error: e.message }; statuses[k].r2 = 'failed'; statuses[k].r2Error = e.message; }
    }
    // Pass C2: each AI receives its own sealed estimate plus the independent critiques and produces a final review.
    for (const k of names) {
      try {
        if (!names.every(n => rounds.r2[n]?.ok) || !rounds.r1[k]?.ok) throw new Error('Blocked because all 4 valid debate responses and this AI’s Round 1 forecast are required.');
        const debates = names.map(n => ({ anonymousDebate: rounds.r2[n].parsed }));
        const p = normalize(parseJson(await aiCall(k, promptFor(f, ctx, 3, debates, rounds.r1[k].parsed))));
        rounds.r3[k] = { ok: true, parsed: p }; statuses[k].r3 = 'ok';
      } catch (e) { rounds.r3[k] = { ok: false, error: e.message }; statuses[k].r3 = 'failed'; statuses[k].r3Error = e.message; }
    }
    const valid = names.every(k => rounds.r1[k]?.ok && rounds.r2[k]?.ok && rounds.r3[k]?.ok);
    const checklist = makeChecklist(ctx, rounds, valid);
    const hardGates = ['Official fixture identity', 'Current table', 'Opponent-adjusted last five', 'xG/xGA/npxG', 'Team news', 'GK + centre-backs', 'Player ratings + depth', 'Motivation', 'AI Round 1', 'AI Round 2 debate', 'AI Round 3 revision', 'Probability audits', 'Dated source freshness'];
    const qualified = valid && checklist.coverage >= 90 && hardGates.every(label => checklist.items.find(x => x.label === label)?.ok === true);
    let final = null;
    if (valid) {
      const ps = names.map(k => rounds.r3[k].parsed);
      const avg = key => ps.reduce((s, p) => s + Number(p.probabilities[key]), 0) / ps.length;
      const probs = { home: avg('home'), draw: avg('draw'), away: avg('away'), over25: avg('over25'), under25: avg('under25'), bttsYes: avg('bttsYes'), bttsNo: avg('bttsNo') };
      const tri = probs.home + probs.draw + probs.away; for (const k of ['home', 'draw', 'away']) probs[k] /= tri;
      const scoreMap = new Map();
      for (const p of ps) for (const s of p.topScores) {
        const old = scoreMap.get(s.score) || { score: s.score, probability: 0, count: 0 };
        old.probability += Number(s.probability) / ps.length; old.count++; scoreMap.set(s.score, old);
      }
      const topScores = [...scoreMap.values()].sort((a, b) => b.probability - a.probability).slice(0, 3);
      final = {
        lambdaHome: ps.reduce((s, p) => s + Number(p.lambdaHome), 0) / ps.length,
        lambdaAway: ps.reduce((s, p) => s + Number(p.lambdaAway), 0) / ps.length,
        probabilities: probs, topScores,
        drawAssessments: ps.map(p => p.drawAssessment || ''),
        contextAssessments: ps.map(p => ({ teamNews: p.teamNews, gkCb: p.gkCb, tactics: p.tactics, motivationSchedule: p.motivationSchedule, managerChange: p.managerChange, uncertainty: p.uncertainty, risks: p.risks, dataGaps: p.dataGaps })),
        consensusMethod: 'Unweighted mean of four valid post-debate AI forecasts; not a trained or backtested ensemble.'
      };
    }
    job.result = {
      fixture: f, createdAt: new Date().toISOString(), qualified,
      finalReason: qualified ? 'All coded qualification gates passed; this is not a guarantee.' : `NOT QUALIFIED — critical evidence/coverage gates remain unmet${valid ? '' : ' or one or more AI rounds failed'}; coverage ${checklist.coverage}%.`,
      failure: valid ? '' : 'Debate incomplete; final consensus is withheld when any required AI/round fails.',
      aiStatuses: statuses, passA, final, aiRounds: rounds, checklist,
      dataGaps: ctx.dataGaps, researchSources: ctx.sources,
      debateSummary: valid ? 'All four AIs completed three rounds. Averaged probabilities are shown with disagreement and missing evidence.' : 'Debate incomplete; no final consensus forecast is published.'
    };
    job.status = 'complete';
  } catch (e) {
    job.status = 'complete';
    job.result = { fixture: input.fixture, createdAt: new Date().toISOString(), qualified: false, finalReason: 'NOT QUALIFIED — backend analysis failed closed.', failure: e.message, aiStatuses: {}, dataGaps: [e.message], final: null };
  }
}
async function testAll() {
  const results = {};
  for (const k of providerNames) {
    try {
      if (k === 'football') {
        if (!env.APISPORTS_KEY) throw new Error('APISPORTS_KEY missing');
        await football('/status');
        results[k] = { configured: true, status: 'connected', lastTest: 'connected', message: 'API request succeeded' };
      } else if (k === 'research') {
        if (!env.TAVILY_API_KEY) throw new Error('TAVILY_API_KEY missing');
        await tavily('football fixtures test');
        results[k] = { configured: true, status: 'connected', lastTest: 'connected', message: 'Search request succeeded' };
      } else {
        const c = AI_CONFIG[k]; if (!c.key) throw new Error(`${k} API key missing`);
        await aiCall(k, 'Return only valid JSON: {"status":"OK"}.');
        results[k] = { configured: true, status: 'connected', lastTest: 'connected', model: c.model, reasoningRequested: c.effort, reasoningModeRequested: c.mode, message: 'API call succeeded' };
      }
    } catch (e) {
      const c = AI_CONFIG[k];
      results[k] = { configured: Boolean(k === 'football' ? env.APISPORTS_KEY : k === 'research' ? env.TAVILY_API_KEY : c?.key), status: 'failed', lastTest: 'failed', model: c?.model, reasoningRequested: c?.effort, reasoningModeRequested: c?.mode, message: e.message };
    }
  }
  for (const k of providerNames) state[k] = results[k];
  return { providers: state, checkedAt: new Date().toISOString() };
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'access-control-allow-origin': '*', 'access-control-allow-headers': 'content-type,x-jenga-access-token', 'access-control-allow-methods': 'GET,POST,OPTIONS' });
    return res.end();
  }
  const u = new URL(req.url, 'http://localhost');
  // Keep the platform health probe public; protect every functional API route.
  if (req.method === 'GET' && u.pathname === '/health') return json(res, 200, { ok: true, service: 'Jenga Football V3.0 backend', startedAt, now: new Date().toISOString(), version: '1.2.0-automation-model-refresh' });
  if (!auth(req)) return json(res, 401, { error: env.NODE_ENV === 'production' && !token ? 'JENGA_ACCESS_TOKEN must be configured before using the API.' : 'Invalid Jenga app access token' });
  try {
    if (req.method === 'GET' && u.pathname === '/api/status') return json(res, 200, { providers: state, startedAt });
    if (req.method === 'POST' && u.pathname === '/api/test-connections') return json(res, 200, await testAll());
    if (req.method === 'GET' && u.pathname === '/api/football/leagues') {
      const season = u.searchParams.get('season') || String(new Date().getFullYear());
      const j = await football(`/leagues?season=${encodeURIComponent(season)}`);
      return json(res, 200, { leagues: (j.response || []).map(x => ({ id: x.league?.id, name: x.league?.name, country: x.country?.name || '', season: x.seasons?.find(s => String(s.year) === String(season))?.year || Number(season), coverage: x.seasons?.find(s => String(s.year) === String(season))?.coverage || {} })) });
    }
    if (req.method === 'GET' && u.pathname === '/api/football/fixtures') {
      const from = u.searchParams.get('from'), to = u.searchParams.get('to'), season = u.searchParams.get('season'), ids = (u.searchParams.get('leagueIds') || '').split(',').filter(Boolean);
      if (!from || !to || !season || !ids.length) return json(res, 400, { error: 'from, to, season and leagueIds are required' });
      const all = [];
      for (const id of ids) {
        const j = await football(`/fixtures?league=${encodeURIComponent(id)}&season=${encodeURIComponent(season)}&from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`);
        for (const x of j.response || []) all.push({ id: x.fixture?.id, date: x.fixture?.date?.slice(0, 10), time: x.fixture?.date?.slice(11, 16), home: x.teams?.home?.name, away: x.teams?.away?.name, league: x.league?.name, country: x.league?.country, status: x.fixture?.status?.long, level: 'unknown', levelVerified: false, homeId: x.teams?.home?.id, awayId: x.teams?.away?.id, leagueId: x.league?.id, providerFixture: x });
      }
      return json(res, 200, { fixtures: all, leaguesChecked: ids.length });
    }
    if (req.method === 'POST' && u.pathname === '/api/analyze') {
      const input = await bodyOf(req);
      if (!input.fixture?.id) return json(res, 400, { error: 'Fixture with official provider ID is required' });
      const activeJobs = [...jobs.values()].filter(j => j.status === 'queued' || j.status === 'running').length;
      if (activeJobs >= 1) return json(res, 429, { error: 'Another analysis is already running. Wait until it completes before starting another fixture.' });
      if (jobs.size > 1000) { for (const [id, j] of jobs) if (j.status === 'complete') jobs.delete(id); }
      const jobId = crypto.randomUUID();
      jobs.set(jobId, { status: 'queued', createdAt: new Date().toISOString(), result: null });
      void analyze(jobId, input);
      return json(res, 202, { jobId, status: 'queued' });
    }
    const jm = u.pathname.match(/^\/api\/analyze\/([^/]+)$/);
    if (req.method === 'GET' && jm) {
      const job = jobs.get(jm[1]);
      if (!job) return json(res, 404, { error: 'Analysis job not found or server restarted' });
      return json(res, 200, { jobId: jm[1], status: job.status, result: job.result });
    }
    return json(res, 404, { error: 'Route not found' });
  } catch (e) { return json(res, 500, { error: e.message || 'Internal server error' }); }
});
server.listen(PORT, '0.0.0.0', () => console.log(`Jenga backend listening on ${PORT}`));
